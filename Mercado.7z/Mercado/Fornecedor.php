<?php

include_once 'Conexao.php';


class Fornecedor extends Conexao{


	public function selectall(){

		$resultados = $this->query("SELECT * FROM fornecedores");
		$resultados->execute();

		return $resultados->fetchall(PDO::FETCH_ASSOC);

	}




	public function insert ($nome){

		$query = $this->prepare("INSERT INTO fornecedores (nome) VALUES (:nome) ");
		$query->bindParam(':nome', $nome);
		$query->execute();
	}



}

?>