<?php

include_once 'Produto.php';
include_once 'Fornecedor.php';

$produto = new Produto();

$produtos = $produto->update($_POST['nome'], $_POST['peso'], $_POST['preco'],$_GET['id'], $_POST['fornecedor_id']);


header('location: index.php');



?>