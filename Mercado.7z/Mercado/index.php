<?php

include_once 'Fornecedor.php';
include_once 'Produto.php';

$fornecedor = new Fornecedor();

$fornecedores = $fornecedor->selectall();

$produto = new Produto();

$produtos = $produto->selectall();


?>


<!DOCTYPE html>
<html>
<head>
	<title>Mercado</title>
	<meta charset="utf-8">
</head>
<body>

	<form method="POST" action="cadastra_fornecedor.php">

		<input type="text" name="nome" placeholder="Nome do fornecedor">
		<button type="submit">Cadastrar</button>

	</form>

	<form method="POST" action="cadastra_produto.php">

		<input type="text" name="nome" placeholder="Nome do produto">
		<input type="text" name="peso" placeholder="Peso do produto">
		<input type="text" name="preco" placeholder="Preço ($) do produto">

		<select name="fornecedor_id">
			<?php foreach($fornecedores as $fornecedor) { ?> 	

				<option value="<?php echo $fornecedor['id'] ?> " > <?php echo $fornecedor['nome'] ?> </option>

			<?php }	?>
		</select>

		<button type="submit">Cadastrar</button>

	</form>

	<table border="1px" >
		<thead>
			<tr>
				<th>Nome Produto</th>
				<th>Peso</th>
				<th>Preço</th>
				<th>Nome do Fornecedor</th>
				<th>Editar</th>
				<th>Deletar</th>

			</tr>
		</thead>
		<tbody>
			<?php foreach($produtos as $produto){ ?>

			<tr>			
				<td> <?php echo $produto['nome']; ?></td>
				<td> <?php echo $produto['peso']; ?></td>
				<td> <?php echo $produto['preco']; ?></td>	
				<td> <?php echo $produto['nome_fornecedor']; ?></td>
				<td><a href="edita_produto.php?id=<?php echo $produto['id']; ?>">Atualizar</a></td>
				<td><a href="deleta_produto.php?id=<?php echo $produto['id']; ?>">Deletar</a></td>
			</tr>
			<?php } ?>				
		</tbody>
	</table>



</body>
</html>