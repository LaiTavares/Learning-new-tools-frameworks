<?php 

include_once 'Conexao.php';

class Produto extends Conexao{


	public function selectall(){

		$resultados = $this->query("SELECT produtos.id,produtos.nome, produtos.peso, produtos.preco, fornecedores.nome AS nome_fornecedor FROM produtos JOIN fornecedores ON produtos.fornecedor_id = fornecedores.id ");

		$resultados->execute();

		return $resultados->fetchall(PDO::FETCH_ASSOC);

	}


	public function insert ($nome, $peso, $preco, $fornecedor_id){
		$query = $this->prepare("INSERT INTO produtos (nome, peso, preco, fornecedor_id) VALUES (:nome, :peso, :preco, :fornecedor_id)");
		$query->bindParam(':nome', $nome);
		$query->bindParam(':peso', $peso);
		$query->bindParam(':preco', $preco);
		$query->bindParam(':fornecedor_id', $fornecedor_id);

		$query->execute();
	}


	public function get ($id){
		$query = $this->prepare("SELECT * FROM produtos WHERE produtos.id = :id");
		$query->bindParam(':id', $id);
		$query->execute();
		return $query->fetchall(PDO::FETCH_ASSOC);
	}


	public function update($nome, $peso, $preco, $id, $fornecedor_id){

		$query = $this->prepare("UPDATE produtos SET nome = :nome, peso = :peso, preco = :preco, fornecedor_id = :fornecedor_id WHERE id = :id");
		$query->bindParam(':nome', $nome);
		$query->bindParam(':peso', $peso);
		$query->bindParam(':preco', $preco);
		$query->bindParam(':fornecedor_id', $fornecedor_id);
		$query->bindParam(':id', $id);
		$query->execute();		


	}


	public function delete ($id){

		$query = $this->prepare("DELETE FROM produtos WHERE id = :id");
		$query->bindParam('id', $id);
		$query->execute();
	}



}


?>