<?php

include_once 'Produto.php';
include_once 'Fornecedor.php';

$produto = new Produto();

$produto->delete($_GET['id']);


header('location: index.php');



?>