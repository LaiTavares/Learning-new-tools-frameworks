<?php

class Conexao extends PDO{

	public function __construct(){
		$PDO_DSN = "mysql:host=localhost;dbname=supermercado;charset=utf8";
		Parent::__construct ($PDO_DSN, "root", "");
	}
}

?>