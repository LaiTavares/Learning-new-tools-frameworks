<?php

include_once 'Fornecedor.php';

$nome = $_POST['nome'];

$fornecedor = new Fornecedor();

$fornecedor->insert($nome);

header('location: index.php');

?>