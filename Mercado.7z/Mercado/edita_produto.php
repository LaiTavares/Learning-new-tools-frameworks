<?php 
include_once 'Produto.php';
include_once 'Fornecedor.php';

$produto = new Produto();

$produtoedit = $produto->get($_GET['id']);

$fornecedor = new Fornecedor();

$fornecedores = $fornecedor->selectall();

?>

<!DOCTYPE html>
<html>
<head>
	<title>Mercado</title>
	<meta charset="utf-8">
</head>
<body>


	<form method="POST" action="edicao.php?id=<?php echo $_GET['id'] ?>">

		<input type="text" name="nome" value="<?php echo $produtoedit[0]['nome']; ?>">
		<input type="text" name="peso" value="<?php echo $produtoedit[0]['peso']; ?>">
		<input type="text" name="preco" value="<?php echo $produtoedit[0]['preco']; ?>">

		<select name="fornecedor_id">
			<?php foreach($fornecedores as $fornecedor) { ?>

			<option <?php echo $fornecedor['id'] == $produtoedit[0]['fornecedor_id'] ? "selected" : "" ?> value="<?php echo $fornecedor['id'] ?> " > <?php echo $fornecedor['nome'] ?> </option>
			<?php }	?>
		</select>
		<button type="submit">Atualizar</button>

	</form>


</body>
</html>