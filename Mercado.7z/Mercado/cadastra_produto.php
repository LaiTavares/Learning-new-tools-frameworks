<?php

include_once 'Produto.php';

$nome = $_POST ['nome'];
$peso = $_POST ['peso'];
$preco = $_POST ['preco'];
$fornecedor_id = $_POST ['fornecedor_id'];

$produto = new Produto;

$produto->insert($nome, $peso, $preco, $fornecedor_id);

header('location: index.php');

?>